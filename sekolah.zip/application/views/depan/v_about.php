<!--============================= WELCOME TITLE =============================-->
<section class="welcome_about">
    <div class="container">
        <div class="row">
            <div class="col-md-5">
                <img src="<?php echo base_url().'theme/images/38218726dr.sofiyah.jfif'?>" class="img-fluid" alt="#">
            </div>
            <div class="col-md-7">
                <h2>Kata Sambutan</h2>
                <p>Assalammualaykum Warahmatullahi Wabarakatuh
                    <br><br>
                    Yang Saya Hormati : <br>
                    Para Walimurid, Siswa dan siswi Indonesia, Cendikiawan
                    <br><br>
                    Saya UcapkanSelamat datang di website kami<br>
                    Alhamdulillah Hirabbilalamin,
                    segala puji hanya bagi Allah Subhanahuwataala Tuhan semesta Alam, <br>
                    Sholawat serta salam kita sampaikan kepada Junjungan Nabi Muhammad Salallahualayhi Wassalam, suri tauladan terbaik sepanjang zaman.<br>
                    </p>
                    <p>
                    Saya bersyukur Allah Subhanahuwataala menakdirkan saya diantara barisan orang-orang yang berjuang didunia pendidikan sebagai kepala sekolah, guru, terkhusus sebagai guru di SMK Kesehatan Al-hadiriyah, karena kami yakin ini adalah profesi terbaik dan mulia.Semoga Allah Subhanahuwataala kuatkan kami dalam mendidik dan kami dapat memberikan yang terbaik untuk anak-anak ku sekalian, agar tercapai semua harapan doa dan keinginan serta cita-cita kalian semuanya
                    </p>
                    <br>
                    Wassalammualaykum Warahmatullahi Wabarakatuh
                    <br><br>
                    salam sukses dari saya
                    Kepala  SMK Al-Hadiriyah
                    <br>
                    Hj.dr.Sofiyah 
                </p>
            </div>
            </div>
        </div>
    </section>
    <!--//END WELCOME TITLE -->
    <!--============================= TESTIMONIAL =============================-->
    <!-- <section class="testimonial">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h2>Testimonial</h2>
                </div>
                <div class="col-md-12">
                    <div class="single-item">
                        <div class="quote">
                            <i class="fa fa-quote-left" aria-hidden="true"></i>
                            <p class="quote_text">MSCHOOL benar-benar mengagumkan. Saya sangat senang bisa bergabung dengan MSCHOOL dan menjadi siswa terbaik tahun 2018.</p>
                            <div class="testi-img_block">
                                <img src="<?php #echo base_url().'assets/images/student-1.png'?>" class="img-fluid" alt="#">
                                <p><span>Hernandez Alvaro</span>Siswa Terbaik 2018</p>
                            </div>
                        </div>
                        <div class="quote">
                            <i class="fa fa-quote-left" aria-hidden="true"></i>
                            <p class="quote_text">MSCHOOL benar-benar mengagumkan. Saya sangat senang bisa bergabung dengan MSCHOOL dan menjadi siswa terbaik tahun 2017. </p>
                            <div class="testi-img_block">
                                <img src="<?php #echo base_url().'theme/images/student-2.png'?>" class="img-fluid" alt="#">
                                <p><span>Elanoar Rigby</span>Siswa Terbaik 2017</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section> -->
    <!--//END TESTIMONIAL -->
    <!--============================= DETAILED CHART =============================-->
    <!-- <div class="detailed_chart">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-6 col-md-3 chart_bottom">
                    <div class="chart-img">
                        <img src="<?php #echo base_url().'theme/images/chart-icon_1.png'?>" class="img-fluid" alt="chart_icon">
                    </div>
                    <div class="chart-text">
                        <p><span class="counter"><?php #echo $tot_guru;?></span> Guru
                        </p>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-6 col-md-3 chart_bottom chart_top">
                    <div class="chart-img">
                        <img src="<?php #echo base_url().'theme/images/chart-icon_2.png'?>" class="img-fluid" alt="chart_icon">
                    </div>
                    <div class="chart-text">
                        <p><span class="counter"><?php #echo $tot_siswa;?></span> Siswa
                        </p>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-6 col-md-3 chart_top">
                    <div class="chart-img">
                        <img src="<?php #echo base_url().'theme/images/chart-icon_3.png'?>" class="img-fluid" alt="chart_icon">
                    </div>
                    <div class="chart-text">
                        <p><span class="counter"><?php #echo $tot_files;?></span> Download
                        </p>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-6 col-md-3">
                    <div class="chart-img">
                        <img src="<?php #echo base_url().'theme/images/chart-icon_4.png'?>" class="img-fluid" alt="chart_icon">
                    </div>
                    <div class="chart-text">
                        <p><span class="counter"><?php #echo $tot_agenda;?></span> Agenda</p>
                    </div>
                </div>
            </div>
        </div>
    </div> -->
    <!--//END DETAILED CHART -->