<?php
<div class="box-body">

          <textarea class="ckeditor" name="xisi" required><?php echo $b['tulisan_isi'];?></textarea>

        </div>