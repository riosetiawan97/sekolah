<!--============================= Gallery =============================-->
<section>
<div class="gallery-wrap">
  <div class="container">
  <!-- Style 2 -->
    <!-- <div class="row">
      <div class="col-md-12">
        <h3 class="gallery-style">Alur Pendaftaran</h3>
      </div>
    </div><br> -->
   <div class="row">
    <!-- SELECT2 EXAMPLE -->
      <div class="box box-primary">
        <div class="box-header with-border">
          <h3 class="box-title">Pendaftaran</h3>
          <div class="box-tools pull-right">
            <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
          </div>
        </div>
        <!-- /.box-header -->
        <div class="box-body">
          <iframe src="<?php echo $setup->formpendaftaran;?>" width="100%" height="3700px" frameborder="0"></iframe>
        </div>
        <!-- /.box-body -->
        <!-- <div class="box-footer">
          Visit <a href="https://select2.github.io/">Select2 documentation</a> for more examples and information about
          the plugin.
        </div> -->
      </div>
      <!-- /.box -->
    </div>
    <!--//End Style 2 -->
  </div>
</div>
<!--//End Gallery -->
</section>